/* Arnia março/2022
 * SCRIPT MODELO ARNIA PARA INICIANTES
 * Objetivo: o objetivo desse script não é servir de referência de boas práticas e
 * sim para facilitar a introdução inicial à programação. Para alunos que nunca tiveram contato
 * com a programação
 *
 * Exemplo para declaração de variáveis
 * let n = 0
 * Exemplo de comando de saída
 * io.write('Toda ciência tem sua linguagem')
 * Exemplo de entrada de dados
 * n = io.readInt()
 */
// no início não se preocupe com esta linha
const io = require("./io")

//declare suas variáveis aqui

//comece suas instruções
